package teste.com.daniel.aula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaJavaApplication.class, args);
	}

}
