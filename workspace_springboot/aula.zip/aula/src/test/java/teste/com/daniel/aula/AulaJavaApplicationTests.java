package teste.com.daniel.aula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
